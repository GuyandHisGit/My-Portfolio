import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoadingComponent implements OnInit {
  greetings: { text: string; x: string; y: string }[] = [];
  showMainGreeting = true
  availableGreetings = [
    '¡Hola!', 'Bonjour!', 'Hallo!', 'Ciao!', 'Olá!', 'Hallo!', 'Привет!', '你好!', 'こんにちは!',
    '안녕하세요!', 'नमस्ते!', 'হ্যালো!', 'مرحبًا!', 'Merhaba!', 'Γειά σου!'
  ];

  ngOnInit() {
    setTimeout(() => {
      this.showMainGreeting = false;
      this.startRandomGreetings();
    }, 500);
  }

  startRandomGreetings() {
    let index = 0;
    const interval = setInterval(() => {
      if (index >= this.availableGreetings.length) {
        clearInterval(interval);
      } else {
        const x = Math.random() * 80 + 'vw';
        const y = Math.random() * 80 + 'vh';
        this.greetings.push({ text: this.availableGreetings[index], x, y });
        index++;
        setTimeout(() => {
          this.greetings.shift(); // Remove after animation
        }, 1000);
      }
    }, 200);
  }
}